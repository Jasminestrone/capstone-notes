# **Abstract**

Modern life increasingly requires participation in more and more digital systems, and the relationship with technology that we are building is increasingly unsustainable. People are increasingly feeling as if they've lost control, relegated to passengers of their own lives. Gen Z has been most affected by this, with only 14% feeling comfortable with their screen time[^1]. Yet many report being unable to change; 80% cite FOMO and lack of motivation as the biggest factors keeping them on their phones, 28% are actively struggling to cut back, and 12% have given up trying entirely[^2]. This review examines the neuroscience of boredom, its connection to the brain's default mode network, the consequences of its elimination by modern technology, and why existing solutions have failed. I propose that the answer is not in restricting phone use, but in reclaiming boredom itself through a purposefully boring "micro-gadget" built on the basis of neuroscience research.

# **Background**

## **The Neuroscience of Boredom**

When one has nothing to do and no task to focus on, one's brain doesn't simply 'shut down'; it activates the default mode network (DMN). The DMN is in charge of some of the most important cognitive processes we have: self-analysis, self-reflection, memory of self, and high-level life planning[^3].

The self-reflection hypothesis of the DMN suggests that during periods of rest, the network facilitates reflection on past experiences and future possibilities, allowing you to plan possible scenarios for your life[^4]. The DMN has a large part in creative thinking. A 2024 study published in Brain found that creativity can be reliably predicted by the frequency of switches between the DMN and the executive control network (ECN). This suggests that the cooperation between undirected thought and focused cognition is the foundation of creative problem-solving[^5].

## **Boredom Through History**

The discomfort we feel with boredom isn't new; however, our ability to escape it is. For most of human history, boredom was an inescapable part of daily life, and cultures developed frameworks for understanding and even valuing it. The ancient Greeks and Christian monks both identified it as acedia, and "noonday demon,"[^6]. This was treated as a challenge that required endurance, and, if endured, as a doorway to deeper contemplation and spiritual growth[^7]. In contrast, today it's seen as something we must get rid of immediately.

The word "boredom" itself didn't even enter common English usage until the mid-19th century, roughly coinciding with industrialization and the restructuring of daily life around productivity and scheduled time[^8]. Before that, the experience existed but was understood differently: as melancholy, or as a condition of the soul rather than a problem to be solved. For pre-industrial societies, unstructured time was simply the texture of existence. People stared out windows and walked without a destination. These were simply seen as a part of life. Philosopher Bertrand Russell, in his 1930 essay The Conquest of Happiness, proposes that "a certain power of enduring boredom is essential to a happy life," and that the modern inability to tolerate it was producing a generation incapable of deep thought[^9].

What has changed is not the human experience of boredom but the availability of escape from it. Each technological era has shortened the gap between the onset of boredom and the availability of stimulation, from books to radio to television to the internet, but smartphones represent something qualitatively different: they have eliminated the gap. Boredom has been made entirely optional in 2026\.

## **The Elimination of Boredom**

Despite the importance of the DMN, modern technology has found a way to shut it off almost entirely. Apps like TikTok, Instagram Reels, and YouTube Shorts have effectively "cured" boredom by providing infinite on-demand stimulation via scrolling short-form content. The moment one feels even a flicker of discomfort from having nothing to do, one of these apps can be opened in a matter of seconds to fill the void. The result is staggering and, frankly, horrifying: 83% of respondents in a recent survey reported spending zero time "relaxing or thinking" in the past 24 hours[^10].

Research suggests that this isnt a matter of preference or personal choice, instead that we find the experience of directionless thought deeply uncomfortable[^11]. In a landmark 2014 study published in Science, Wilson et al. left participants alone in a room for 6 to 15 minutes with nothing to do but think. 67% of male participants and 25% of female participants chose to administer painful electric shocks to themselves rather than sit with their own thoughts, participants who had previously stated they would pay money to avoid being shocked again[^12].

But why does boredom feel so intolerable in the first place? Psychologist John Eastwood and colleagues define boredom as "the aversive experience of wanting, but being unable, to engage in satisfying activity," a state in which one is painfully aware of one's own failure to pay attention to anything meaningful[^13]. The discomfort is not incidental; it is the entire point. Bench and Lench argue that boredom functions as an emotional signal, much like pain or hunger, that evolved to push organisms toward action[^14]. The experience is deliberately negative, characterized by a sense of time slowing and feeling trapped, because this aversiveness is what motivates the search for new goals and novel environments. From an evolutionary standpoint, an animal content to sit still in one ecological niche is dangerously vulnerable; boredom is the mechanism that drives exploration, risk-taking, and adaptability[^15]. Wolff, Rewitz, and Bieleke frame it as the counterpart to self-control: where willpower keeps you locked onto a long-term goal, boredom is the "undirected signal to do something else" that ensures you don't exploit one strategy to the point of collapse[^16]. In short, we find boredom unbearable because we were designed to. It is a feature, not a bug, one that for most of history served us well by pushing us toward creativity, exploration, and growth. The problem is that this ancient motivational system now has something it was never designed to encounter: an instant, infinite, and effortless escape hatch.

The scale of phone dependency among Gen Z is hard to overstate. 68% of Gen Z respondents report feeling anxious when separated from their smartphones, compared to only 37% of Baby Boomers[^17]. 63% check their phones within five minutes of waking due to fear of missing out[^18]. Smartphones prove to be the hardest device for Gen Z to put down, with 61% ranking them as the most difficult to reduce usage on[^19]. The black box in everyone's pocket has become a crutch against the discomfort of an idle mind, and the consequences are rapidly becoming evident.

## **The Consequences**

Gen Z is now facing a mental health crisis that researchers are increasingly linking to the elimination of boredom. A 2023 Gallup survey found that almost half of Gen Z individuals, 12-2,6 often or always feel anxious, and more than one in five often or always feel depressed[^20]. A review of 50 studies covering roughly 1.9 million adolescents found that excessive screen time is correlated with mental health problems, with smartphone use during weekdays particularly correlated with diminished well-being.[^21]

The connection between screen time and a lack of purpose is particularly concerning. A Harvard report found that half of Gen Z young adults say their mental health is negatively affected by not knowing the direction of their lives, and nearly three in five reported lacking meaning or purpose in their lives within the past month[^22]. Arthur Brooks, in the \*Harvard Business Review\*, argues that these are a direct result of each other. He suggests that the avoidance of boredom through constant device use creates a "doom loop of meaning," where introspection brought on by the DMN, which historically was used to figure out one's purpose, is being nearly entirely prevented[^23].

## **Existing Responses and Why They Fall Short**

The tech industry's response to the screen time crisis has mostly used restrictive tactics, such ast screen time tracking apps, app blockers, usage timers, and guilt-based notifications telling users they have exceeded their daily limit. Research, however, has shown that screen time tracking alone has little effect on phone behavior six weeks after implementation[^24]. Default rules such as time limits and pre-scheduled downtime fail to exert sustainable influence because you don't perceive tangible negative consequences when you dismiss these nudges; you just tap through them[^25]. One study found that while design friction interventions like grayscale mode led to immediate reductions in screen time, they produced no measurable improvement in subjective well-being or academic performance, which raises the question of whether reducing screen time alone is even the right goal[^26].

Cal Newport, in his book \*Digital Minimalism\*, argues that willpower-based tips and screen time apps are fundamentally insufficient as the solutions they offer treat symptoms rather than the cause. What is needed, he writes, is "a full philosophy of technology use" that gives people a compelling reason to put their phones down, not just a barrier preventing them from picking them up[^27]. Every major solution on the market focuses on restriction, and restriction alone does not address the underlying FOMO and motivational problem that 80% of Gen Z identifies as the reason they can't stop[^28].

The field of Design for Behavior Change offers a useful lens for understanding why restriction-based approaches fail and what might actually work. BJ Fogg's Behavior Model, developed at Stanford,  suggests that behavior change requires three elements: sufficient motivation, adequate ability, and an effective trigger[^29]. Screen time apps operate almost entirely on the trigger dimension, with notifications and timers, while doing nothing to address motivation or ability. This is the same mistake that early anti-smoking campaigns made. Telling people that cigarettes were harmful did not produce widespread behavior change; what was needed was a combination of nicotine replacement therapies that addressed the physical craving, environmental redesign that removed smoking from public spaces, and social reinforcement that made not smoking the default[^30].

Similarly, for gambling addiction, self-exclusion programs, in which individuals voluntarily ban themselves from gambling venues, have short-term success when used by themselves because they don't provide other options for any psychological rewards that gambling was delivering[^31]. The same principle applies to smartphone dependency: taking the phone away, or limiting its use, does not address the emotional and cognitive needs that the phone was meeting. Without a compelling alternative that fulfills some of those same needs in a healthier manner, people will simply find ways around the restriction.

There is a growing movement of deliberately limited devices that represent a more promising direction. The Micro-journal project offers an open-source, open-hardware distraction-free writing device in the genre of writerDecks[^32]. The Xteink X4 is a 74-gram, wallet-sized e-ink reader that magnetically snaps onto the back of your phone via MagSafe; it has no touchscreen, no frontlight, no app store, and no internet connection[^33]. One review argued that reading apps on phones fail because they compete with notifications and social feeds, so you end up doomscrolling instead of finishing that novel[^34]. The X4 is magnetically attached to the thing you're trying to use less; it's always right there as an alternative. The Tangara is an open-source, open-hardware portable music player inspired by the iPod, built around an ESP32 with a capacitive touch wheel, 3.5mm jack, and Bluetooth[^35].

These "boring gadgets" share a philosophy of doing less on purpose, and they are each solving problems. The X4, Tangara, and Micro-journal all address the idea that reading, music, and writing devices are also your doomscrolling and notifications device. But none of them are built around the neuroscience of why boredom itself matters. They replace specific phone activities with dedicated alternatives, which is incredibly valuable as a first step, but they don't actively create space for the kind of undirected thinking that the DMN requires. They give you something to do instead of scrolling; nothing gives you nothing to do, which is what the DMN actually needs. The gap remains: no existing device offers a compelling, neuroscience-grounded replacement that makes doing nothing feel worth doing.

## **Conclusions**

\- Boredom is not something to be cured; it is essential to reclaim. The DMN requires space to operate and drives the introspection, creativity, and sense of purpose that Gen Z is increasingly missing.  
\- The elimination of boredom through constant digital stimulation is directly linked to rising rates of depression, anxiety, and a pervasive lack of purpose among young Gen Z.  
\- Restriction-based approaches to screen time, from apps to timers to nudges, have consistently failed because they do not address the underlying motivational and emotional drivers of phone dependency.  
\- The gap in the market and in the research is a device that does not just limit technology use, but offers a neuroscience-grounded alternative that makes "doing nothing" feel worth doing.

# **Methodology**

# **Research problem**

83% of Gen Z reports spending zero time "relaxing or thinking" in the past 24 hours. The default mode network, the part of the brain responsible for self-reflection, creativity, and life planning, needs idle time to function. Smartphones have eliminated idle time. While existing solutions to decreasing function all rely on restriction, this project would instead give you something else to do. Can a physical open-source device make doing nothing worth doing?

# **Process approach**

This project follows an industrial design process similar to what the Tangara, Micro-journal, and Xteink X4 teams used to develop their deliberately limited devices. Each of those projects went through cycles of research, prototyping, user feedback, and refinement.  
The process I'm using has 6 main phases: research/interviews, sketching and looks like modeling, works like modeling, complete prototypes, final testing, and open sourcing it to give back to the communities that helped create it. 

## **Phase 1: Research**

**Case studies.** I'm analyzing three existing "boring gadgets": the Xteink X4 (e-ink reader that magnetically attaches to your phone), the Tangara (open-source music player), and the Micro-journal (open-source distraction-free writing device). Each of these solves the problem of phone activities living on a phone. None of them addresses the deeper problem my literature review identified: that the DMN needs you to do nothing, not just something different. The case studies help me understand what these projects got right in terms of form factor, interaction design, and open-source community building, and where the gap still lies.

**Interviews.** I'll be conducting semi-structured interviews with two groups. The first is Gen Z users (ages 18-26) about their relationship with boredom, their phone habits, and what "doing nothing" feels like for them. The second group is advisors with backgrounds in behavioral science and neuroscience, to pressure-test whether my design decisions actually align with how the DMN works.

**Analyzing themes.** I'm using the interviews and case studies to identify recurring patterns. Based on the literature review, I expect themes around FOMO as an emotional driver, the discomfort of undirected thought, and the gap between wanting to use the phone less and actually being able to. New/unanticipated themes will hopefully emerge from the interviews.

## **Phase 2: Creation**

**Sketching.** I'm generating at least five different form factor concepts for the micro-gadget. These need to answer basic questions: size, shape, and contact points. The Xteink X4 decided to be wallet-sized and touchscreenless with no frontlight. The Tangara went with a capacitive touch wheel. I need to figure out what interaction model makes sense for a device whose entire purpose is to encourage not interacting with it.

**CAD modeling.** I'm using Fusion 360 to model the chosen concepts. I have more experience in Rhino, but I want to develop my Fusion skills, and Fusion is better suited to this project as its modeling allows for faster iteration. The CAD models need to be detailed enough to 3D print functional prototypes with internal space for electronics (likely an ESP32).

**Scale prototypes.** I'm building iterative physical prototypes that combine the electronics (works-like) with the form factor (looks-like). Milestone 3 is a working prototype with the electronics working. Milestone 4 combines the work-like internals with the looks-like exterior. Each round of prototyping feeds into user testing, which feeds back into the next round.

## **Phase 3: Testing**

**User tests.** I'm putting prototypes in front of Gen Z users and watching what happens. Do they pick it up? Do they understand it without explanation? Do they reach for their phone anyway? The Fogg Behavior Model says behavior change needs motivation, ability, and a trigger. Screen time apps only provide the trigger. This device needs to provide motivation and ability. User tests will tell me if I'm hitting those marks.

**Ergonomics.** This is a device that needs to fit into someone's daily life, which means it needs to be comfortable to carry, easy to hold, and not annoying. I'm evaluating size, weight, texture, and pocket-friendliness across prototypes. The X4 weighs 74 grams and is wallet-sized, which is the kind of constraint I'm working within. If it's too big or too heavy, nobody carries it, and a device you leave at home is a device that doesn't work.

**Pilot study.** Toward the end of the project, a small group of Gen Z participants (5-8 people) will use a near-final prototype for 3-5 days in their normal routine. I want to know if they carry it, use it, did it influence their sense of self, and did their screentime change? This is qualitative data from a check-in interview. The sample is too small for statistical significance, but it can tell me whether the concept has legs.

# **Data collection and analysis**

## **Sampling**

I'll recruit Gen Z participants (ages 15-21) from NuVu. This is a convenience sample, not a representative one. I'm looking for people who self-identify as wanting to use their phone less, since the ExpressVPN survey found 46% of Gen Z actively take measures to limit screen time. That's my target user. I'm aiming for 8-12 interview participants and 5-8 pilot study participants.

## **Limitations**

This is a capstone project, and we don't have the resources or time for a clinical trial. The sample size is small and drawn from one high school, so I can't generalize the findings. The pilot study is too short to measure long-term behavior change; it can only indicate whether the concept is promising enough to pursue further. I'm also not a neutral party. I started this project because I think boredom is worth reclaiming, and that shows up in how I framed the literature review. 

The open-source component adds a constraint: every design decision needs to be documented well enough for someone else to reproduce it. That slows things down, but it's also a feature. If the device works, other people should be able to build one.

## **Expect Outcomes**

The primary deliverable is a working physical prototype of the micro-gadget: a pocket-sized open-hardware device designed to make idle time feel worth inhabiting. Secondary deliverables include:

* Complete open-source documentation: hardware files, bill of materials, assembly instructions, and Fusion 360 source files published in a public repository  
* Interview findings summarizing Gen Z attitudes toward boredom, phone dependency, and what they actually want from unstructured time  
* Pilot study qualitative data indicating whether the prototype changes carry or use behavior in daily life  
* A comprehensive presentation with renderings, process documentation, and design rationale  
* Final product that demonstrates how a final version of this device may look.

The pilot study will not produce statistically significant results. What it can do is indicate whether the concept is promising enough for further development by others in the open-source community.

## **Advisors**

**Jamie Shushan** \-Master's in higher education from Harvard, 17 years working at the Crimson Summer Academy studying student-phone relationships in the context of studying and productivity. Can offer behavioral insight into the target age group and pressure-test whether the device concept addresses the right problem.

**Megan Reitz** — Professor at Hult International Business School researching mindful leadership and attention. Can provide depth on the psychological cost of constant digital stimulation and the value of mental stillness in relation to the capstone's core argument that boredom is a neurological need.

**Unkyulee** \- Creator of the Micro-journal open-source writerDeck project Can provide practical guidance on open-hardware development, community building, and the realities of designing a deliberately limited device from scratch.

## **Competencies**

Skills I'm bringing into this project: open-source software and documentation practices, semi-structured interviewing, survey design, Rhino 3D, and general CAD intuition built from prior projects.

Skills I'm developing through this project: open hardware design (PCB layout, component selection, firmware), Fusion 360 (switching from Rhino because Fusion handles parametric iteration and integrated CAM better for this kind of enclosure work), and enough electronics to build and iterate on an ESP32-based prototype without needing to outsource the works-like phase.

## **Schedule**

| Milestone | Description |
| ----- | ----- |
| 1 | Research and interviews: case studies, semi-structured interviews with Gen Z users and advisors, theme analysis |
| 2 | Sketching and looks-like: at least 5 form factor concepts, light physical models, interaction model selected |
| 3 | Works-like prototype: electronics functional, firmware running, form factor rough |
| 4 | Complete prototype: works-like internals inside looks-like enclosure, ready for user testing |
| 5 | User testing and pilot study: ergonomics evaluation, 3-5 day pilot with 5-8 participants, check-in interviews |
| 6 | Final prototype: refinements from pilot study incorporated, final physical model complete |
| 7 | Open sourcing: repository published with full documentation, renderings, and process notes |

## **Budget**

| Item | Estimated Cost |
| ----- | ----- |
| ESP32 microcontroller (×3 for iteration) | $30–45 |
| E-ink or minimal display module | $15–30 |
| Battery \+ charging circuit (TP4056 or similar) | $10–20 |
| 3D printing materials (PLA/PETG across iterations) | $20–40 |
| Miscellaneous hardware (fasteners, connectors, wire) | $15–25 |
| PCB fabrication if a  custom board needed | $20–50 |
| **Total estimate** | **$110–210** |

Costs are kept low by using off-the-shelf modules rather than custom silicon, which also makes the design more reproducible for anyone building from the open-source files.

[^1]:  ExpressVPN, "Survey: 46% of Gen Z take measures to limit screen time," \*ExpressVPN Blog\*, August 21, 2024\. https://www.expressvpn.com/blog/digital-minimalism-generational-insights

[^2]:  Arthur C. Brooks, "You Need to Be Bored. Here's Why," \*Harvard Business Review\*, August 28, 2025\. https://hbr.org/2025/08/you-need-to-be-bored-heres-why

[^3]:  Arthur C. Brooks, "You Need to Be Bored. Here's Why," \*Harvard Business Review\*, August 28, 2025\. https://hbr.org/2025/08/you-need-to-be-bored-heres-why

[^4]:  Raichle, M. E., "The Brain's Default Mode Network," \*Annual Review of Neuroscience\*, 2015\. See also: "The Journey of the Default Mode Network: Development, Function, and Impact on Mental Health," \*PMC\*, 2025\. https://pmc.ncbi.nlm.nih.gov/articles/PMC12025022/

[^5]:  Ferrante, O. et al., "Default mode network electrophysiological dynamics and causal role in creative thinking," \*Brain\*, vol. 147, no. 10, pp. 3409–3422, 2024\. https://academic.oup.com/brain/article/147/10/3409/7695856

[^6]:  Toohey, P., \*Boredom: A Lively History\*, Yale University Press, 2011\. ISBN: 9780300181845\. https://yalebooks.yale.edu/book/9780300181845/boredom/

[^7]:  Toohey, P., \*Boredom: A Lively History\*, Yale University Press, 2011\. ISBN: 9780300181845\. https://yalebooks.yale.edu/book/9780300181845/boredom/

[^8]:  Toohey, P., \*Boredom: A Lively History\*, Yale University Press, 2011\. ISBN: 9780300181845\. https://yalebooks.yale.edu/book/9780300181845/boredom/

[^9]:  Russell, B., \*The Conquest of Happiness\*, Chapter 4: "Boredom and Excitement," W.W. Norton & Company, 1930isn't.

[^10]:  ExpressVPN, "Survey: 46% of Gen Z take measures to limit screen time," \*ExpressVPN Blog\*, August 21, 2024\. https://www.expressvpn.com/blog/digital-minimalism-generational-insights

[^11]:  Arthur C. Brooks, "You Need to Be Bored. Here's Why," \*Harvard Business Review\*, August 28, 2025\. https://hbr.org/2025/08/you-need-to-be-bored-heres-why

[^12]:  Wilson, T. D. et al., "Just think: The challenges of the disengaged mind," \*Science\*, vol. 345, no. 6192, pp. 75–77, July 4, 2014\. https://pmc.ncbi.nlm.nih.gov/articles/PMC4330241/

[^13]:  Eastwood, J. D., Frischen, A., Fenske, M. J., & Smilek, D., "The Unengaged Mind: Defining Boredom in Terms of Attention," \*Perspectives on Psychological Science\*, vol. 7, no. 5, pp. 482–495, 2012\. https://doi.org/10.1177/1745691612456044

[^14]:  Bench, S. W. & Lench, H. C., "On the Function of Boredom," \*Behavioral Sciences\*, vol. 3, no. 3, pp. 459–472, 2013\. https://doi.org/10.3390/bs3030459

[^15]:  Bench, S. W. & Lench, H. C., "On the Function of Boredom," \*Behavioral Sciences\*, vol. 3, no. 3, pp. 459–472, 2013\. https://doi.org/10.3390/bs3030459

[^16]:  Wolff, W., Rewitz, K., & Bieleke, M., "Bug or feature? Boredom feels aversive, and this is why it matters," \*In-Mind Magazine\*, issue 52, 2024\. https://www.in-mind.org/article/bug-or-feature-boredom-feels-aversive-and-this-is-why-it-matters

[^17]:  "Gen Z Leads the Charge: The Steep Rise of Digital Minimalism," \*TechCabal\*, December 10, 2024\. https://techcabal.com/2024/12/10/gen-z-leads-the-charge-the-steep-rise-of-digital-minimalism

[^18]:  "Gen Z Leads the Charge: The Steep Rise of Digital Minimalism," \*TechCabal\*, December 10, 2024\. https://techcabal.com/2024/12/10/gen-z-leads-the-charge-the-steep-rise-of-digital-minimalism

[^19]:  ExpressVPN, "Survey: 46% of Gen Z take measures to limit screen time," \*ExpressVPN Blog\*, August 21, 2024\. https://www.expressvpn.com/blog/digital-minimalism-generational-insights

[^20]:  "Generation Z's Mental Health Issues," \*The Annie E. Casey Foundation\*, 2024\. https://www.aecf.org/blog/generation-z-and-mental-hasasealth

[^21]:  Santos, R. M. S. et al., "The associations between screen time and mental health in adolescents: a systematic review," \*BMC Psychology\*, April 20, 2023\. https://pmc.ncbi.nlm.nih.gov/articles/PMC10117262/

[^22]:  "Gen Z young adults face double the depression and anxiety of teens, Harvard report finds," \*WBUR News\*, October 24, 2023\. https://www.wbur.org/news/2023/10/24/young-adults-mental-health-harvard-report

[^23]:  Arthur C. Brooks, "You Need to Be Bored. Here's Why," \*Harvard Business Review\*, August 28, 2025\. https://hbr.org/2025/08/you-need-to-be-bored-heres-why

[^24]:  Allcott, H. et al., "Digital Strategies for Screen Time Reduction: A Randomized Field Experiment," \*Cyberpsychology, Behavior, and Social Networking\*, 2022\. See also: "A Nudge-Based Intervention to Reduce Problematic Smartphone Use: Randomised Controlled Trial," \*PMC\*, 2022\. https://pmc.ncbi.nlm.nih.gov/articles/PMC9112639/

[^25]:  Allcott, H. et al., "Digital Strategies for Screen Time Reduction: A Randomized Field Experiment," \*Cyberpsychology, Behavior, and Social Networking\*, 2022\. See also: "A Nudge-Based Intervention to Reduce Problematic Smartphone Use: Randomised Controlled Trial," \*PMC\*, 2022\. https://pmc.ncbi.nlm.nih.gov/articles/PMC9112639/

[^26]:  Allcott, H. et al., "Digital Strategies for Screen Time Reduction: A Randomized Field Experiment," \*Cyberpsychology, Behavior, and Social Networking\*, 2022\. See also: "A Nudge-Based Intervention to Reduce Problematic Smartphone Use: Randomised Controlled Trial," \*PMC\*, 2022\. https://pmc.ncbi.nlm.nih.gov/articles/PMC9112639/

[^27]:  Cal Newport, \*Digital Minimalism: Choosing a Focused Life in a Noisy World\*, Portfolio/Penguin, 2019\.

[^28]:  ExpressVPN, "Survey: 46% of Gen Z take measures to limit screen time," \*ExpressVPN Blog\*, August 21, 2024\. https://www.expressvpn.com/blog/digital-minimalism-generational-insights

[^29]:  Fogg, B. J., "A Behavior Model for Persuasive Design," \*Proceedings of the 4th International Conference on Persuasive Technology (Persuasive '09)\*, pp. 1–7, ACM, 2009\. https://doi.org/10.1145/1541948.1541999

[^30]:  Rigotti, N. A., Kruse, G. R., Livingstone-Banks, J., & Hartmann-Boyce, J., "Treatment of Tobacco Smoking: A Review," \*JAMA\*, vol. 327, no. 6, pp. 566–577, 2022\. https://doi.org/10.1001/jama.2022.0395

[^31]:  Gainsbury, S. M., "Review of Self-exclusion from Gambling Venues as an Intervention for Problem Gambling," \*Journal of Gambling Studies\*, vol. 30, no. 2, pp. 229–251, 2014\. https://doi.org/10.1007/s10899-013-9362-0. See also: Neophytou, K. et al., "Gambling to escape: A systematic review of the relationship between avoidant emotion regulation/coping strategies and gambling severity," \*Journal of Contextual Behavmore healthilyioral Science\*, vol. 27, pp. 126–142, 2023\. https://doi.org/10.1016/j.jcbs.2023.01.004

[^32]:  Microjournal, open-source writerDeck project. https://github.com/unkyulee/micro-journal

[^33]:  Xteink, "Xteink X4 | Magnetic Ready, Ultra-Thin Paper-like eReader," 2025\. https://www.xteink.com/products/xteink-x4

[^34]:  Sarang Sheth, "Xteink X4 is a wallet-sized eReader That Snaps Onto Your Phone," \*Yanko Design\*, December 9, 2025\. https://www.yankodesign.com/2025/12/09/xteink-x4-is-a-wallet-sized-ereader-that-snaps-onto-your-phone/

[^35]:  Cool Tech Zone, "Tangara: open hardware portable music player," 2024\. https://cooltech.zone/tangara/

---
## Related

[[Literature Review]]
[[Appendix]]
[[Final proposal]]
