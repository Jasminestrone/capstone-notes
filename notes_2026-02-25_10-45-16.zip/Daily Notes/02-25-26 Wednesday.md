### To do
 - [ ] Completely mega finalize methodology and background
 - [ ] Desk crit with ryan and akshay
### Top priority
1. Methodology
2. Background
3. Making them work well together
### Done
-
### Blockers / waiting on
- 
### Notes
- 
****
Template [[Daily notes]]